import { Hono } from 'npm:hono'
import { cors } from 'npm:hono/cors'
import { logger } from 'npm:hono/logger'
import { createClient } from 'npm:@supabase/supabase-js'
import * as kv from './kv_store.tsx'

const app = new Hono()

app.use('*', cors({
  origin: '*',
  allowHeaders: ['*'],
  allowMethods: ['*'],
}))

app.use('*', logger(console.log))

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
)

// Health check endpoint
app.get('/make-server-6aae87c3/health', (c) => {
  return c.json({ status: 'ok', timestamp: new Date().toISOString() })
})

// Get all portfolio projects
app.get('/make-server-6aae87c3/projects', async (c) => {
  try {
    console.log('Fetching projects from KV store...')
    const rawProjects = await kv.getByPrefix('project:')
    console.log('Raw projects from KV:', rawProjects)
    
    let projects = []
    
    if (Array.isArray(rawProjects)) {
      projects = rawProjects.map((item, index) => {
        try {
          // Handle different possible data structures
          let projectData
          let projectId
          
          if (item && typeof item === 'object') {
            // Case 1: {key: 'project:123', value: {...}}
            if (item.key && item.key.startsWith('project:')) {
              projectId = item.key.replace('project:', '')
              projectData = typeof item.value === 'string' ? JSON.parse(item.value) : item.value
            }
            // Case 2: Direct object with project data
            else if (item.title || item.id) {
              projectData = item
              projectId = item.id || `project-${index}`
            }
            // Case 3: String value that needs parsing
            else {
              projectData = typeof item === 'string' ? JSON.parse(item) : item
              projectId = projectData.id || `project-${index}`
            }
          } else {
            // Fallback: treat as string
            projectData = typeof item === 'string' ? JSON.parse(item) : item
            projectId = projectData?.id || `project-${index}`
          }
          
          if (!projectData) {
            console.warn('No project data found for item:', item)
            return null
          }
          
          return {
            id: projectId,
            title: projectData.title || 'Untitled Project',
            category: projectData.category || 'General',
            description: projectData.description || 'No description available',
            thumbnail: projectData.thumbnail || 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=800&h=600&fit=crop',
            tags: Array.isArray(projectData.tags) ? projectData.tags : [],
            createdAt: projectData.createdAt || new Date().toISOString()
          }
        } catch (parseError) {
          console.error('Error parsing project data:', parseError, 'Item:', item)
          return null
        }
      }).filter(Boolean)
    }
    
    console.log('Processed projects:', projects)
    
    return c.json({ 
      success: true,
      projects,
      count: projects.length 
    })
  } catch (error) {
    console.error('Error fetching projects:', error)
    return c.json({ 
      error: 'Failed to fetch projects',
      details: error.message,
      timestamp: new Date().toISOString()
    }, 500)
  }
})

// Add a new portfolio project
app.post('/make-server-6aae87c3/projects', async (c) => {
  try {
    const body = await c.req.json()
    console.log('Creating project with data:', body)
    
    const { title, category, description, thumbnail, tags } = body
    
    if (!title || !category || !description || !thumbnail) {
      return c.json({ 
        error: 'Missing required fields',
        required: ['title', 'category', 'description', 'thumbnail'],
        received: Object.keys(body)
      }, 400)
    }
    
    const projectId = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
    const project = {
      id: projectId,
      title,
      category,
      description,
      thumbnail,
      tags: Array.isArray(tags) ? tags : (tags ? tags.split(',').map(t => t.trim()) : []),
      createdAt: new Date().toISOString()
    }
    
    await kv.set(`project:${projectId}`, project)
    console.log('Created project:', projectId, project)
    
    return c.json({ 
      success: true, 
      project
    })
  } catch (error) {
    console.error('Error creating project:', error)
    return c.json({ 
      error: 'Failed to create project',
      details: error.message,
      timestamp: new Date().toISOString()
    }, 500)
  }
})

// Update a portfolio project
app.put('/make-server-6aae87c3/projects/:id', async (c) => {
  try {
    const projectId = c.req.param('id')
    const body = await c.req.json()
    console.log('Updating project:', projectId, body)
    
    const existingProject = await kv.get(`project:${projectId}`)
    if (!existingProject) {
      return c.json({ error: 'Project not found' }, 404)
    }
    
    const updatedProject = {
      ...existingProject,
      ...body,
      id: projectId,
      tags: Array.isArray(body.tags) ? body.tags : (body.tags ? body.tags.split(',').map(t => t.trim()) : existingProject.tags),
      updatedAt: new Date().toISOString()
    }
    
    await kv.set(`project:${projectId}`, updatedProject)
    console.log('Updated project:', projectId, updatedProject)
    
    return c.json({ 
      success: true, 
      project: updatedProject
    })
  } catch (error) {
    console.error('Error updating project:', error)
    return c.json({ 
      error: 'Failed to update project',
      details: error.message,
      timestamp: new Date().toISOString()
    }, 500)
  }
})

// Delete a portfolio project
app.delete('/make-server-6aae87c3/projects/:id', async (c) => {
  try {
    const projectId = c.req.param('id')
    console.log('Deleting project:', projectId)
    
    const existingProject = await kv.get(`project:${projectId}`)
    if (!existingProject) {
      return c.json({ error: 'Project not found' }, 404)
    }
    
    await kv.del(`project:${projectId}`)
    console.log('Deleted project:', projectId)
    
    return c.json({ success: true })
  } catch (error) {
    console.error('Error deleting project:', error)
    return c.json({ 
      error: 'Failed to delete project',
      details: error.message,
      timestamp: new Date().toISOString()
    }, 500)
  }
})

// Submit contact form
app.post('/make-server-6aae87c3/contact', async (c) => {
  try {
    const body = await c.req.json()
    console.log('Processing contact form:', body)
    
    const { firstName, lastName, email, projectType, budget, message } = body
    
    if (!firstName || !lastName || !email || !message) {
      return c.json({ 
        error: 'Missing required fields',
        required: ['firstName', 'lastName', 'email', 'message'],
        received: Object.keys(body)
      }, 400)
    }
    
    const contactId = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
    const contact = {
      id: contactId,
      firstName,
      lastName,
      email,
      projectType: projectType || '',
      budget: budget || '',
      message,
      status: 'new',
      submittedAt: new Date().toISOString()
    }
    
    await kv.set(`contact:${contactId}`, contact)
    console.log('Contact form submitted:', contactId, contact)
    
    return c.json({ 
      success: true, 
      message: 'Thank you for your inquiry! I\'ll get back to you within 24 hours.',
      contactId 
    })
  } catch (error) {
    console.error('Error processing contact form:', error)
    return c.json({ 
      error: 'Failed to submit contact form',
      details: error.message,
      timestamp: new Date().toISOString()
    }, 500)
  }
})

// Get all contact submissions (for admin)
app.get('/make-server-6aae87c3/contacts', async (c) => {
  try {
    console.log('Fetching contacts from KV store...')
    const rawContacts = await kv.getByPrefix('contact:')
    console.log('Raw contacts from KV:', rawContacts)
    
    let contacts = []
    
    if (Array.isArray(rawContacts)) {
      contacts = rawContacts.map((item, index) => {
        try {
          let contactData
          let contactId
          
          if (item && typeof item === 'object') {
            // Case 1: {key: 'contact:123', value: {...}}
            if (item.key && item.key.startsWith('contact:')) {
              contactId = item.key.replace('contact:', '')
              contactData = typeof item.value === 'string' ? JSON.parse(item.value) : item.value
            }
            // Case 2: Direct object with contact data
            else if (item.firstName || item.id) {
              contactData = item
              contactId = item.id || `contact-${index}`
            }
            else {
              contactData = typeof item === 'string' ? JSON.parse(item) : item
              contactId = contactData.id || `contact-${index}`
            }
          } else {
            contactData = typeof item === 'string' ? JSON.parse(item) : item
            contactId = contactData?.id || `contact-${index}`
          }
          
          if (!contactData) {
            console.warn('No contact data found for item:', item)
            return null
          }
          
          return {
            id: contactId,
            ...contactData
          }
        } catch (parseError) {
          console.error('Error parsing contact data:', parseError, 'Item:', item)
          return null
        }
      }).filter(Boolean).sort((a, b) => new Date(b.submittedAt).getTime() - new Date(a.submittedAt).getTime())
    }
    
    console.log('Processed contacts:', contacts)
    
    return c.json({ 
      success: true,
      contacts,
      count: contacts.length 
    })
  } catch (error) {
    console.error('Error fetching contacts:', error)
    return c.json({ 
      error: 'Failed to fetch contacts',
      details: error.message,
      timestamp: new Date().toISOString()
    }, 500)
  }
})

// Update contact status
app.put('/make-server-6aae87c3/contacts/:id/status', async (c) => {
  try {
    const contactId = c.req.param('id')
    const { status } = await c.req.json()
    console.log('Updating contact status:', contactId, status)
    
    const existingContact = await kv.get(`contact:${contactId}`)
    if (!existingContact) {
      return c.json({ error: 'Contact not found' }, 404)
    }
    
    const updatedContact = {
      ...existingContact,
      status,
      updatedAt: new Date().toISOString()
    }
    
    await kv.set(`contact:${contactId}`, updatedContact)
    console.log('Updated contact status:', contactId, status)
    
    return c.json({ success: true })
  } catch (error) {
    console.error('Error updating contact status:', error)
    return c.json({ 
      error: 'Failed to update contact status',
      details: error.message,
      timestamp: new Date().toISOString()
    }, 500)
  }
})

// Initialize with sample projects if none exist
app.post('/make-server-6aae87c3/init', async (c) => {
  try {
    console.log('Initializing sample data...')
    const existingProjects = await kv.getByPrefix('project:')
    console.log('Existing projects count:', existingProjects?.length || 0)
    
    if (!existingProjects || existingProjects.length === 0) {
      const sampleProjects = [
        {
          title: "Corporate Brand Film",
          category: "Commercial",
          description: "A sophisticated brand story that showcases innovation and company values through dynamic cinematography.",
          thumbnail: "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=800&h=600&fit=crop",
          tags: ["Corporate", "Branding", "4K"]
        },
        {
          title: "Wedding Highlight Reel",
          category: "Wedding",
          description: "Romantic storytelling captured in golden hour light, preserving precious moments for a lifetime.",
          thumbnail: "https://images.unsplash.com/photo-1606216794074-735e91aa2c92?w=800&h=600&fit=crop",
          tags: ["Wedding", "Cinematic", "Emotional"]
        },
        {
          title: "Music Video Production",
          category: "Music",
          description: "High-energy visual narrative synchronized with rhythm, featuring creative lighting and dynamic camera movements.",
          thumbnail: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=800&h=600&fit=crop",
          tags: ["Music", "Creative", "Performance"]
        }
      ]
      
      for (let i = 0; i < sampleProjects.length; i++) {
        const projectId = `${Date.now() + i}-sample`
        const projectData = {
          id: projectId,
          ...sampleProjects[i],
          createdAt: new Date().toISOString()
        }
        await kv.set(`project:${projectId}`, projectData)
        console.log('Created sample project:', projectId)
      }
      
      console.log('Initialized with sample projects')
      return c.json({ 
        success: true, 
        message: 'Sample projects created',
        count: sampleProjects.length 
      })
    }
    
    return c.json({ 
      success: true, 
      message: 'Projects already exist',
      count: existingProjects.length 
    })
  } catch (error) {
    console.error('Error initializing:', error)
    return c.json({ 
      error: 'Failed to initialize',
      details: error.message,
      timestamp: new Date().toISOString()
    }, 500)
  }
})

// Clear all data (for testing purposes)
app.delete('/make-server-6aae87c3/clear-all', async (c) => {
  try {
    console.log('Clearing all data...')
    
    // Get all keys with project: and contact: prefixes
    const [projects, contacts] = await Promise.all([
      kv.getByPrefix('project:'),
      kv.getByPrefix('contact:')
    ])
    
    // Delete all projects
    if (Array.isArray(projects)) {
      for (let i = 0; i < projects.length; i++) {
        const item = projects[i]
        if (item && item.key) {
          await kv.del(item.key)
        } else {
          // If we can't get the key, try to construct it
          await kv.del(`project:${Date.now()}-${i}`)
        }
      }
    }
    
    // Delete all contacts  
    if (Array.isArray(contacts)) {
      for (let i = 0; i < contacts.length; i++) {
        const item = contacts[i]
        if (item && item.key) {
          await kv.del(item.key)
        } else {
          await kv.del(`contact:${Date.now()}-${i}`)
        }
      }
    }
    
    console.log('Cleared all data')
    return c.json({ 
      success: true, 
      message: 'All data cleared',
      cleared: { projects: projects?.length || 0, contacts: contacts?.length || 0 }
    })
  } catch (error) {
    console.error('Error clearing data:', error)
    return c.json({ 
      error: 'Failed to clear data',
      details: error.message,
      timestamp: new Date().toISOString()
    }, 500)
  }
})

// Catch all for debugging
app.all('*', (c) => {
  console.log('Unmatched route:', c.req.method, c.req.url)
  return c.json({ 
    error: 'Route not found',
    method: c.req.method,
    url: c.req.url,
    timestamp: new Date().toISOString()
  }, 404)
})

console.log('Server starting...')
Deno.serve(app.fetch)