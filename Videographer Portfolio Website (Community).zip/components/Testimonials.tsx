import { Star, Quote } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export default function Testimonials() {
  const testimonials = [
    {
      id: 1,
      name: 'Emma & James Wilson',
      role: 'Wedding Clients',
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&q=80',
      rating: 5,
      content: "Sarah captured our wedding day so beautifully. Every emotion, every detail, every precious moment was preserved perfectly. The photos are absolutely stunning and we couldn't be happier with the results. LensCraft Studio exceeded all our expectations.",
      project: 'Wellington Botanical Garden Wedding'
    },
    {
      id: 2,
      name: 'Michael Chen',
      role: 'Corporate Client',
      image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&q=80',
      rating: 5,
      content: "Professional, creative, and incredibly skilled. The headshots Sarah took for our company rebrand were exactly what we needed. She understood our vision immediately and delivered photos that perfectly represent our brand values.",
      project: 'Corporate Headshots & Branding'
    },
    {
      id: 3,
      name: 'Lisa Thompson',
      role: 'Family Portrait Client',
      image: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&q=80',
      rating: 5,
      content: "Working with LensCraft Studio was an amazing experience. Sarah made our family feel so comfortable and natural during the shoot. The final photos are breathtaking - we have them displayed throughout our home and receive compliments constantly.",
      project: 'Extended Family Portrait Session'
    },
    {
      id: 4,
      name: 'David & Sarah Martinez',
      role: 'Engagement Session',
      image: 'https://images.unsplash.com/photo-1566492031773-4f4e44671d66?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&q=80',
      rating: 5,
      content: "The engagement photos exceeded our wildest dreams! Sarah's artistic eye and ability to capture genuine emotions made our session feel effortless. We can't wait to work with her again for our wedding. Highly recommend LensCraft Studio!",
      project: 'Waterfront Engagement Session'
    },
    {
      id: 5,
      name: 'Rebecca Foster',
      role: 'Personal Branding',
      image: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&q=80',
      rating: 5,
      content: "As a small business owner, I needed professional photos that would help my brand stand out. Sarah understood exactly what I was looking for and created images that perfectly capture my personality and professionalism. Investment well worth it!",
      project: 'Personal Branding Photography'
    },
    {
      id: 6,
      name: 'Tom & Rachel Green',
      role: 'Maternity & Newborn',
      image: 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&q=80',
      rating: 5,
      content: "From our maternity session to our newborn photos, Sarah has documented our journey into parenthood beautifully. Her patience with our baby and ability to capture those fleeting moments is truly remarkable. These photos are priceless to us.",
      project: 'Maternity & Newborn Photography'
    }
  ];

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, index) => (
      <Star
        key={index}
        className={`w-5 h-5 ${index < rating ? 'fill-amber-400 text-amber-400' : 'text-gray-300'}`}
      />
    ));
  };

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl text-gray-900 mb-6">What Our Clients Say</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Don't just take our word for it. Here's what our amazing clients have to say about 
            their experience working with LensCraft Studio.
          </p>
        </div>

        {/* Featured Testimonial */}
        <div className="bg-white rounded-3xl shadow-xl p-12 mb-16 max-w-4xl mx-auto">
          <div className="text-center">
            <Quote className="w-12 h-12 text-amber-400 mx-auto mb-6" />
            <blockquote className="text-2xl md:text-3xl text-gray-900 italic mb-8 leading-relaxed">
              "Sarah captured our wedding day so beautifully. Every emotion, every detail, 
              every precious moment was preserved perfectly. The photos are absolutely stunning 
              and we couldn't be happier with the results."
            </blockquote>
            <div className="flex items-center justify-center space-x-4">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&q=80"
                alt="Emma & James Wilson"
                className="w-16 h-16 rounded-full object-cover"
              />
              <div className="text-left">
                <div className="text-xl text-gray-900">Emma & James Wilson</div>
                <div className="text-gray-600">Wellington Botanical Garden Wedding</div>
                <div className="flex mt-2">{renderStars(5)}</div>
              </div>
            </div>
          </div>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.slice(1).map((testimonial) => (
            <div key={testimonial.id} className="bg-white rounded-2xl shadow-lg p-8 hover:shadow-xl transition-shadow duration-300">
              <div className="flex mb-4">{renderStars(testimonial.rating)}</div>
              
              <blockquote className="text-gray-700 mb-6 leading-relaxed">
                "{testimonial.content}"
              </blockquote>
              
              <div className="flex items-center space-x-4">
                <ImageWithFallback
                  src={testimonial.image}
                  alt={testimonial.name}
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div>
                  <div className="text-gray-900">{testimonial.name}</div>
                  <div className="text-sm text-gray-600">{testimonial.project}</div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Stats Section */}
        <div className="mt-20 bg-gradient-to-r from-amber-500 to-yellow-600 rounded-3xl p-12 text-white">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl mb-2">500+</div>
              <div className="text-amber-100">Happy Clients</div>
            </div>
            <div>
              <div className="text-4xl mb-2">1000+</div>
              <div className="text-amber-100">Projects Completed</div>
            </div>
            <div>
              <div className="text-4xl mb-2">8+</div>
              <div className="text-amber-100">Years Experience</div>
            </div>
            <div>
              <div className="text-4xl mb-2">5★</div>
              <div className="text-amber-100">Average Rating</div>
            </div>
          </div>
        </div>

        <div className="text-center mt-12">
          <button className="bg-white text-amber-600 px-8 py-4 rounded-full hover:bg-gray-50 transition-all duration-300 transform hover:scale-105 shadow-lg">
            Read More Reviews
          </button>
        </div>
      </div>
    </section>
  );
}