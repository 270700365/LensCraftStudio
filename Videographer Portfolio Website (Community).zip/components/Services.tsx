import { Heart, Users, Building, ArrowRight } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export default function Services() {
  const services = [
    {
      icon: Heart,
      title: 'Portrait Photography',
      description: 'Professional headshots, family portraits, and personal branding sessions that capture your unique personality and style.',
      image: 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      features: ['Individual Portraits', 'Family Sessions', 'Professional Headshots', 'Lifestyle Photography'],
      startingPrice: '$300'
    },
    {
      icon: Users,
      title: 'Wedding Photography',
      description: 'Elegant wedding photography that tells your love story with artistry, emotion, and timeless beauty.',
      image: 'https://images.unsplash.com/photo-1519741497674-611481863552?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      features: ['Full Day Coverage', 'Engagement Sessions', 'Bridal Portraits', 'Reception Photography'],
      startingPrice: '$2,500'
    },
    {
      icon: Building,
      title: 'Commercial Photography',
      description: 'High-quality commercial photography for businesses, products, and marketing materials that drive results.',
      image: 'https://images.unsplash.com/photo-1556761175-4b46a572b786?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      features: ['Product Photography', 'Corporate Events', 'Architecture', 'Marketing Materials'],
      startingPrice: '$400'
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl text-gray-900 mb-6">Our Services</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We specialize in creating stunning visual stories that capture the essence of every moment, 
            from intimate portraits to grand celebrations.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div key={index} className="bg-white rounded-2xl shadow-xl overflow-hidden hover:shadow-2xl transition-shadow duration-300">
              <div className="relative h-64 overflow-hidden">
                <ImageWithFallback
                  src={service.image}
                  alt={service.title}
                  className="w-full h-full object-cover transform hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-4 left-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-amber-400 to-yellow-600 rounded-full flex items-center justify-center">
                    <service.icon className="w-6 h-6 text-white" />
                  </div>
                </div>
              </div>
              
              <div className="p-8">
                <h3 className="text-2xl text-gray-900 mb-4">{service.title}</h3>
                <p className="text-gray-600 mb-6 leading-relaxed">{service.description}</p>
                
                <div className="mb-6">
                  <h4 className="text-lg text-gray-900 mb-3">What's Included:</h4>
                  <ul className="space-y-2">
                    {service.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center text-gray-600">
                        <div className="w-2 h-2 bg-amber-400 rounded-full mr-3"></div>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="flex justify-between items-center">
                  <div>
                    <span className="text-sm text-gray-500">Starting from</span>
                    <div className="text-2xl text-amber-600">{service.startingPrice}</div>
                  </div>
                  <button className="flex items-center space-x-2 text-amber-600 hover:text-amber-700 transition-colors group">
                    <span>Learn More</span>
                    <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <button className="bg-gradient-to-r from-amber-500 to-yellow-600 text-white px-8 py-4 rounded-full hover:from-amber-600 hover:to-yellow-700 transition-all duration-300 transform hover:scale-105">
            View All Services & Pricing
          </button>
        </div>
      </div>
    </section>
  );
}