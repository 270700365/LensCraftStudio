import { ImageWithFallback } from './figma/ImageWithFallback';
import { Camera, Award, Heart, Users } from 'lucide-react';

export default function About() {
  const values = [
    {
      icon: Camera,
      title: 'Artistic Vision',
      description: 'We approach every shoot with a unique creative perspective, ensuring your photos stand out with artistic flair.'
    },
    {
      icon: Heart,
      title: 'Passion Driven',
      description: 'Our love for photography shines through in every image we capture, creating meaningful connections with our subjects.'
    },
    {
      icon: Award,
      title: 'Professional Excellence',
      description: 'Years of experience and continuous learning ensure we deliver the highest quality results for every client.'
    },
    {
      icon: Users,
      title: 'Client Focused',
      description: 'We prioritize your vision and needs, working closely with you to exceed expectations on every project.'
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main About Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center mb-20">
          <div>
            <h2 className="text-4xl md:text-5xl text-gray-900 mb-8">About LensCraft Studio</h2>
            <div className="space-y-6 text-lg text-gray-600 leading-relaxed">
              <p>
                Located in the vibrant heart of Cuba Street, Wellington, LensCraft Studio has been 
                capturing life's most precious moments for over eight years. Founded by award-winning 
                photographer Sarah Mitchell, our boutique studio specializes in creating timeless, 
                artistic images that tell your unique story.
              </p>
              <p>
                We believe that every photograph should be a work of art – a perfect blend of technical 
                excellence and creative vision. Our approach combines classical photography techniques 
                with modern artistic sensibilities, ensuring your images are both beautiful and meaningful.
              </p>
              <p>
                Whether it's an intimate portrait session, a joyous wedding celebration, or a professional 
                commercial shoot, we bring the same level of passion and attention to detail to every project. 
                Our goal is not just to take pictures, but to create lasting memories that you'll treasure forever.
              </p>
            </div>
            
            <div className="mt-8 flex flex-col sm:flex-row gap-4">
              <button className="bg-gradient-to-r from-amber-500 to-yellow-600 text-white px-8 py-4 rounded-full hover:from-amber-600 hover:to-yellow-700 transition-all duration-300 transform hover:scale-105">
                Meet Our Team
              </button>
              <button className="border-2 border-gray-300 text-gray-700 px-8 py-4 rounded-full hover:border-amber-500 hover:text-amber-600 transition-all duration-300">
                Our Process
              </button>
            </div>
          </div>

          <div className="relative">
            <div className="relative rounded-2xl overflow-hidden">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
                alt="LensCraft Studio interior"
                className="w-full h-[600px] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent"></div>
            </div>
            
            {/* Floating Stats Card */}
            <div className="absolute -bottom-8 -left-8 bg-white rounded-2xl shadow-2xl p-6 max-w-xs">
              <div className="text-3xl text-amber-600 mb-2">500+</div>
              <div className="text-gray-900 mb-1">Happy Clients</div>
              <div className="text-sm text-gray-600">Across Wellington & beyond</div>
            </div>
          </div>
        </div>

        {/* Values Section */}
        <div className="bg-gray-50 rounded-3xl p-12">
          <div className="text-center mb-12">
            <h3 className="text-3xl md:text-4xl text-gray-900 mb-4">Our Values</h3>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              The principles that guide our work and define our commitment to exceptional photography
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-amber-400 to-yellow-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <value.icon className="w-8 h-8 text-white" />
                </div>
                <h4 className="text-xl text-gray-900 mb-3">{value.title}</h4>
                <p className="text-gray-600 leading-relaxed">{value.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Location Section */}
        <div className="mt-20 text-center">
          <h3 className="text-3xl md:text-4xl text-gray-900 mb-6">Visit Our Studio</h3>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Located in the creative heart of Wellington, our studio on Cuba Street provides the perfect 
            backdrop for your photography session. Book a consultation to see our space and discuss your vision.
          </p>
          
          <div className="bg-gradient-to-r from-amber-500 to-yellow-600 rounded-2xl p-8 text-white max-w-2xl mx-auto">
            <div className="text-2xl mb-2">📍 Cuba Street, Wellington</div>
            <div className="text-lg opacity-90 mb-4">New Zealand's Creative Quarter</div>
            <button className="bg-white/20 backdrop-blur-sm text-white px-6 py-3 rounded-full hover:bg-white/30 transition-all duration-300">
              Get Directions
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}