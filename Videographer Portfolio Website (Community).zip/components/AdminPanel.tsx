import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Plus, Edit, Trash2, Eye, Mail, Calendar } from 'lucide-react';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface Project {
  id: string;
  title: string;
  category: string;
  description: string;
  thumbnail: string;
  tags: string[];
  createdAt: string;
}

interface Contact {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  projectType: string;
  budget: string;
  message: string;
  status: string;
  submittedAt: string;
}

interface ProjectFormData {
  title: string;
  category: string;
  description: string;
  thumbnail: string;
  tags: string;
}

export default function AdminPanel() {
  const [activeTab, setActiveTab] = useState<'projects' | 'contacts'>('projects');
  const [projects, setProjects] = useState<Project[]>([]);
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [loading, setLoading] = useState(false);
  const [showProjectForm, setShowProjectForm] = useState(false);
  const [editingProject, setEditingProject] = useState<Project | null>(null);
  
  const [projectForm, setProjectForm] = useState<ProjectFormData>({
    title: '',
    category: '',
    description: '',
    thumbnail: '',
    tags: ''
  });

  useEffect(() => {
    if (activeTab === 'projects') {
      fetchProjects();
    } else {
      fetchContacts();
    }
  }, [activeTab]);

  const fetchProjects = async () => {
    setLoading(true);
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-6aae87c3/projects`, {
        headers: { 'Authorization': `Bearer ${publicAnonKey}` },
      });
      const data = await response.json();
      setProjects(data.projects || []);
    } catch (error) {
      console.error('Error fetching projects:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchContacts = async () => {
    setLoading(true);
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-6aae87c3/contacts`, {
        headers: { 'Authorization': `Bearer ${publicAnonKey}` },
      });
      const data = await response.json();
      setContacts(data.contacts || []);
    } catch (error) {
      console.error('Error fetching contacts:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleProjectSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const projectData = {
      ...projectForm,
      tags: projectForm.tags.split(',').map(tag => tag.trim()).filter(Boolean)
    };

    try {
      const url = editingProject 
        ? `https://${projectId}.supabase.co/functions/v1/make-server-6aae87c3/projects/${editingProject.id}`
        : `https://${projectId}.supabase.co/functions/v1/make-server-6aae87c3/projects`;
      
      const response = await fetch(url, {
        method: editingProject ? 'PUT' : 'POST',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(projectData),
      });

      if (response.ok) {
        setProjectForm({ title: '', category: '', description: '', thumbnail: '', tags: '' });
        setShowProjectForm(false);
        setEditingProject(null);
        fetchProjects();
      }
    } catch (error) {
      console.error('Error saving project:', error);
    }
  };

  const handleDeleteProject = async (projectId: string) => {
    if (!confirm('Are you sure you want to delete this project?')) return;

    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-6aae87c3/projects/${projectId}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${publicAnonKey}` },
      });

      if (response.ok) {
        fetchProjects();
      }
    } catch (error) {
      console.error('Error deleting project:', error);
    }
  };

  const handleEditProject = (project: Project) => {
    setEditingProject(project);
    setProjectForm({
      title: project.title,
      category: project.category,
      description: project.description,
      thumbnail: project.thumbnail,
      tags: project.tags.join(', ')
    });
    setShowProjectForm(true);
  };

  const updateContactStatus = async (contactId: string, status: string) => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-6aae87c3/contacts/${contactId}/status`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ status }),
      });

      if (response.ok) {
        fetchContacts();
      }
    } catch (error) {
      console.error('Error updating contact status:', error);
    }
  };

  return (
    <div className="min-h-screen bg-muted/30 p-6">
      <div className="container mx-auto max-w-6xl">
        <div className="mb-8">
          <h1 className="text-3xl mb-4">Admin Panel</h1>
          <div className="flex space-x-4">
            <Button
              variant={activeTab === 'projects' ? 'default' : 'outline'}
              onClick={() => setActiveTab('projects')}
            >
              Portfolio Projects
            </Button>
            <Button
              variant={activeTab === 'contacts' ? 'default' : 'outline'}
              onClick={() => setActiveTab('contacts')}
            >
              Contact Submissions
            </Button>
          </div>
        </div>

        {activeTab === 'projects' && (
          <div>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl">Portfolio Projects</h2>
              <Button
                onClick={() => {
                  setShowProjectForm(!showProjectForm);
                  setEditingProject(null);
                  setProjectForm({ title: '', category: '', description: '', thumbnail: '', tags: '' });
                }}
              >
                <Plus className="mr-2" size={16} />
                Add Project
              </Button>
            </div>

            {showProjectForm && (
              <Card className="p-6 mb-6">
                <h3 className="text-lg mb-4">
                  {editingProject ? 'Edit Project' : 'Add New Project'}
                </h3>
                <form onSubmit={handleProjectSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Input
                      placeholder="Project Title"
                      value={projectForm.title}
                      onChange={(e) => setProjectForm({ ...projectForm, title: e.target.value })}
                      required
                    />
                    <Input
                      placeholder="Category"
                      value={projectForm.category}
                      onChange={(e) => setProjectForm({ ...projectForm, category: e.target.value })}
                      required
                    />
                  </div>
                  <Input
                    placeholder="Thumbnail URL"
                    value={projectForm.thumbnail}
                    onChange={(e) => setProjectForm({ ...projectForm, thumbnail: e.target.value })}
                    required
                  />
                  <Textarea
                    placeholder="Project Description"
                    value={projectForm.description}
                    onChange={(e) => setProjectForm({ ...projectForm, description: e.target.value })}
                    rows={3}
                    required
                  />
                  <Input
                    placeholder="Tags (comma separated)"
                    value={projectForm.tags}
                    onChange={(e) => setProjectForm({ ...projectForm, tags: e.target.value })}
                  />
                  <div className="flex space-x-4">
                    <Button type="submit">
                      {editingProject ? 'Update Project' : 'Add Project'}
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => {
                        setShowProjectForm(false);
                        setEditingProject(null);
                      }}
                    >
                      Cancel
                    </Button>
                  </div>
                </form>
              </Card>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {projects.map((project) => (
                <Card key={project.id} className="p-4">
                  <img
                    src={project.thumbnail}
                    alt={project.title}
                    className="w-full h-32 object-cover rounded mb-3"
                  />
                  <h3 className="mb-2">{project.title}</h3>
                  <Badge variant="secondary" className="mb-2">
                    {project.category}
                  </Badge>
                  <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                    {project.description}
                  </p>
                  <div className="flex space-x-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleEditProject(project)}
                    >
                      <Edit size={14} />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleDeleteProject(project.id)}
                    >
                      <Trash2 size={14} />
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'contacts' && (
          <div>
            <h2 className="text-2xl mb-6">Contact Submissions</h2>
            <div className="space-y-4">
              {contacts.map((contact) => (
                <Card key={contact.id} className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="text-lg">
                        {contact.firstName} {contact.lastName}
                      </h3>
                      <p className="text-muted-foreground">{contact.email}</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge
                        variant={contact.status === 'new' ? 'default' : 'secondary'}
                      >
                        {contact.status}
                      </Badge>
                      <select
                        value={contact.status}
                        onChange={(e) => updateContactStatus(contact.id, e.target.value)}
                        className="text-sm border rounded px-2 py-1"
                      >
                        <option value="new">New</option>
                        <option value="contacted">Contacted</option>
                        <option value="in-progress">In Progress</option>
                        <option value="completed">Completed</option>
                      </select>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div>
                      <span className="text-sm text-muted-foreground">Project Type:</span>
                      <p>{contact.projectType || 'Not specified'}</p>
                    </div>
                    <div>
                      <span className="text-sm text-muted-foreground">Budget:</span>
                      <p>{contact.budget || 'Not specified'}</p>
                    </div>
                  </div>
                  
                  <div className="mb-4">
                    <span className="text-sm text-muted-foreground">Message:</span>
                    <p className="mt-1">{contact.message}</p>
                  </div>
                  
                  <div className="flex items-center justify-between text-sm text-muted-foreground">
                    <div className="flex items-center">
                      <Calendar className="mr-1" size={14} />
                      {new Date(contact.submittedAt).toLocaleDateString()}
                    </div>
                    <a
                      href={`mailto:${contact.email}`}
                      className="flex items-center hover:text-primary"
                    >
                      <Mail className="mr-1" size={14} />
                      Reply
                    </a>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        )}

        {loading && (
          <div className="text-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
            <p>Loading...</p>
          </div>
        )}
      </div>
    </div>
  );
}