import { useState } from 'react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';

export default function Portfolio() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedImage, setSelectedImage] = useState<number | null>(null);

  const categories = [
    { id: 'all', name: 'All Work' },
    { id: 'portraits', name: 'Portraits' },
    { id: 'weddings', name: 'Weddings' },
    { id: 'commercial', name: 'Commercial' }
  ];

  const portfolioItems = [
    {
      id: 1,
      category: 'portraits',
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      title: 'Professional Headshot',
      description: 'Corporate headshot session'
    },
    {
      id: 2,
      category: 'weddings',
      image: 'https://images.unsplash.com/photo-1537633552985-df8429e8048b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      title: 'Garden Wedding',
      description: 'Elegant outdoor ceremony'
    },
    {
      id: 3,
      category: 'commercial',
      image: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      title: 'Product Photography',
      description: 'Luxury watch collection'
    },
    {
      id: 4,
      category: 'portraits',
      image: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      title: 'Fashion Portrait',
      description: 'Creative fashion session'
    },
    {
      id: 5,
      category: 'weddings',
      image: 'https://images.unsplash.com/photo-1606216794074-735e91aa2c92?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      title: 'Bridal Portrait',
      description: 'Intimate bridal session'
    },
    {
      id: 6,
      category: 'commercial',
      image: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      title: 'Architecture',
      description: 'Modern building photography'
    },
    {
      id: 7,
      category: 'portraits',
      image: 'https://images.unsplash.com/photo-1566492031773-4f4e44671d66?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      title: 'Family Portrait',
      description: 'Outdoor family session'
    },
    {
      id: 8,
      category: 'weddings',
      image: 'https://images.unsplash.com/photo-1519741497674-611481863552?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      title: 'Reception Moments',
      description: 'Wedding celebration'
    },
    {
      id: 9,
      category: 'commercial',
      image: 'https://images.unsplash.com/photo-1556761175-4b46a572b786?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      title: 'Corporate Event',
      description: 'Business conference'
    }
  ];

  const filteredItems = selectedCategory === 'all' 
    ? portfolioItems 
    : portfolioItems.filter(item => item.category === selectedCategory);

  const openLightbox = (index: number) => {
    setSelectedImage(index);
  };

  const closeLightbox = () => {
    setSelectedImage(null);
  };

  const navigateLightbox = (direction: 'prev' | 'next') => {
    if (selectedImage === null) return;
    
    if (direction === 'prev') {
      setSelectedImage(selectedImage > 0 ? selectedImage - 1 : filteredItems.length - 1);
    } else {
      setSelectedImage(selectedImage < filteredItems.length - 1 ? selectedImage + 1 : 0);
    }
  };

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl text-gray-900 mb-6">Our Portfolio</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-12">
            Explore our collection of stunning photography across different styles and occasions. 
            Each image tells a unique story crafted with passion and precision.
          </p>

          {/* Category Filter */}
          <div className="flex flex-wrap justify-center gap-4">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`px-6 py-3 rounded-full transition-all duration-300 ${
                  selectedCategory === category.id
                    ? 'bg-gradient-to-r from-amber-500 to-yellow-600 text-white shadow-lg'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {category.name}
              </button>
            ))}
          </div>
        </div>

        {/* Portfolio Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item, index) => (
            <div
              key={item.id}
              className="group relative overflow-hidden rounded-2xl bg-gray-100 cursor-pointer transform hover:scale-105 transition-all duration-500"
              onClick={() => openLightbox(index)}
            >
              <div className="aspect-square">
                <ImageWithFallback
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                />
              </div>
              
              {/* Overlay */}
              <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end">
                <div className="p-6 text-white w-full">
                  <h3 className="text-xl mb-2">{item.title}</h3>
                  <p className="text-gray-200">{item.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Lightbox Modal */}
        {selectedImage !== null && (
          <div className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center p-4">
            <button
              onClick={closeLightbox}
              className="absolute top-4 right-4 text-white hover:text-gray-300 z-60"
            >
              <X className="w-8 h-8" />
            </button>
            
            <button
              onClick={() => navigateLightbox('prev')}
              className="absolute left-4 text-white hover:text-gray-300 z-60"
            >
              <ChevronLeft className="w-8 h-8" />
            </button>
            
            <button
              onClick={() => navigateLightbox('next')}
              className="absolute right-4 text-white hover:text-gray-300 z-60"
            >
              <ChevronRight className="w-8 h-8" />
            </button>

            <div className="max-w-5xl max-h-full">
              <ImageWithFallback
                src={filteredItems[selectedImage].image}
                alt={filteredItems[selectedImage].title}
                className="max-w-full max-h-full object-contain"
              />
              <div className="text-center text-white mt-4">
                <h3 className="text-2xl mb-2">{filteredItems[selectedImage].title}</h3>
                <p className="text-gray-300">{filteredItems[selectedImage].description}</p>
              </div>
            </div>
          </div>
        )}

        <div className="text-center mt-12">
          <button className="bg-gradient-to-r from-amber-500 to-yellow-600 text-white px-8 py-4 rounded-full hover:from-amber-600 hover:to-yellow-700 transition-all duration-300 transform hover:scale-105">
            View Complete Gallery
          </button>
        </div>
      </div>
    </section>
  );
}