import { ImageWithFallback } from './figma/ImageWithFallback';
import { ArrowRight, Award, Users, Camera } from 'lucide-react';

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Hero Background Image */}
      <div className="absolute inset-0">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1606216794074-735e91aa2c92?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2340&q=80"
          alt="Professional photography studio setup"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/40"></div>
      </div>

      {/* Hero Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-5xl md:text-7xl font-light text-white mb-6 leading-tight">
            Capturing Life's
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-amber-400 to-yellow-600">
              Beautiful Moments
            </span>
          </h1>
          
          <p className="text-xl md:text-2xl text-gray-200 mb-8 leading-relaxed">
            Professional photography services in the heart of Wellington. 
            Specializing in portraits, weddings, and commercial photography.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <button className="bg-gradient-to-r from-amber-500 to-yellow-600 text-white px-8 py-4 rounded-full hover:from-amber-600 hover:to-yellow-700 transition-all duration-300 transform hover:scale-105 flex items-center justify-center space-x-2">
              <span>View Portfolio</span>
              <ArrowRight className="w-5 h-5" />
            </button>
            <button className="border-2 border-white text-white px-8 py-4 rounded-full hover:bg-white hover:text-gray-900 transition-all duration-300 backdrop-blur-sm">
              Book Consultation
            </button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-3xl mx-auto">
            <div className="text-center">
              <div className="flex justify-center mb-2">
                <Award className="w-8 h-8 text-amber-400" />
              </div>
              <div className="text-3xl text-white mb-1">8+</div>
              <div className="text-gray-300">Years Experience</div>
            </div>
            <div className="text-center">
              <div className="flex justify-center mb-2">
                <Users className="w-8 h-8 text-amber-400" />
              </div>
              <div className="text-3xl text-white mb-1">500+</div>
              <div className="text-gray-300">Happy Clients</div>
            </div>
            <div className="text-center">
              <div className="flex justify-center mb-2">
                <Camera className="w-8 h-8 text-amber-400" />
              </div>
              <div className="text-3xl text-white mb-1">1000+</div>
              <div className="text-gray-300">Projects Completed</div>
            </div>
          </div>
        </div>
      </div>

      {/* Current Promotions Banner */}
      <div className="absolute bottom-0 left-0 right-0 z-20">
        <div className="bg-gradient-to-r from-amber-500 to-yellow-600 text-white py-3">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <p className="font-medium">
                🎉 Special Offer: Book your session this month and get 20% off portrait packages!
                <span className="ml-2 underline cursor-pointer hover:no-underline">
                  Learn More
                </span>
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}